def calcular_mdc(a, b):
    
    while b != 0:
        a, b = b, a % b
    return a

print("Cálculo do MDC (Máximo Divisor Comum)")
num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))

mdc = calcular_mdc(abs(num1), abs(num2))

print(f"\nO MDC entre {num1} e {num2} é: {mdc}")