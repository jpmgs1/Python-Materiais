# Inicialização das variáveis
numeros = []
contador = 0
soma = 0

print("Digite uma sequência de inteiros positivos (0 para terminar):")

while True:
    try:
        entrada = input("Digite um número: ")
        numero = int(entrada)
        
        if numero == 0:
            break   
        if numero < 0:
            print("Números negativos são desconsiderados. Continue digitando.")
            continue 
        numeros.append(numero)
        contador += 1
        soma += numero
        
    except ValueError:
        print("Por favor, digite apenas números inteiros válidos.")

if contador > 0:
    maior = max(numeros)
    media = soma / contador
else:
    maior = 0
    media = 0

print("\nResultados:")
print(f"Quantidade de números lidos: {contador}")
print(f"Maior número: {maior}")
print(f"Média aritmética: {media:.2f}")