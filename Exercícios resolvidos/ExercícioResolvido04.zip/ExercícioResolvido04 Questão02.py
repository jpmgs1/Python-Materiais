print("Tabela de Conversão: Celsius → Fahrenheit")
print(30 *"-")
print("Celsius\t\tFahrenheit")
print(30 *"-")

for celsius in range(0, 101, 10):
    fahrenheit = 1.8 * celsius + 32
    print(f"{celsius}°C\t\t{fahrenheit:.1f}°F")

print(30 *"-")