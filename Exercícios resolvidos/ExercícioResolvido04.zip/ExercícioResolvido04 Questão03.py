votos_joao = votos_severina = votos_nulos = votos_brancos = 0

print("URNA ELETRÔNICA")
print("As opções são:")
print("0. Finalizar votação")
print("1. Votar em João Rodrigues")
print("2. Votar em Severina da Luz")
print("3. Nulo")
print("4. Branco")

while True:
    try:
        voto = int(input("\nEntre com o seu voto: "))
        if voto == 0:
            break
        elif voto == 1:
            votos_joao += 1
            print("Voto em João Rodrigues registrado!")
        elif voto == 2:
            votos_severina += 1
            print("Voto em Severina da Luz registrado!")
        elif voto == 3:
            votos_nulos += 1
            print("Voto nulo registrado!")
        elif voto == 4:
            votos_brancos += 1
            print("Voto em branco registrado!")
        else:
            print("Opção inválida! Digite um número entre 0 e 4.")
            
    except ValueError:
        print("Por favor, digite apenas números inteiros.")

total_votos = votos_joao + votos_severina + votos_nulos + votos_brancos

print("\nRESULTADO DA ELEIÇÃO")
print(42*"#")
print(f"João Rodrigues: {votos_joao} votos")
print(f"Severina da Luz: {votos_severina} votos")
print(f"Votos nulos: {votos_nulos}")
print(f"Votos em branco: {votos_brancos}")
print(42*"#")

if total_votos > 0:
    perc_nulos = (votos_nulos / total_votos) * 100
    perc_brancos = (votos_brancos / total_votos) * 100
    
    print(f"\nPorcentagem de votos nulos: {perc_nulos:.2f}%")
    print(f"Porcentagem de votos brancos: {perc_brancos:.2f}%")
    
    if votos_joao > votos_severina:
        print("\nRESULTADO: João Rodrigues venceu a eleição!")
    elif votos_severina > votos_joao:
        print("\nRESULTADO: Severina da Luz venceu a eleição!")
    else:
        print("\nRESULTADO: Houve um empate entre os candidatos!")
else:
    print("\nNenhum voto foi registrado!")