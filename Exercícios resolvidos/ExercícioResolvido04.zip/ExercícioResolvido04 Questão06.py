def imprimir_padrao(n):
    for i in range(1, n//2 + 2):
        print('* ' * i)
    
    for i in range(n//2, 0, -1):
        print('* ' * i)

while True:
    try:
        linhas = int(input("Digite o número de linhas (ímpar e maior que zero): "))
        
        if linhas <= 0:
            print("Erro: O número deve ser maior que zero. Tente novamente.")
        elif linhas % 2 == 0:
            print("Erro: O número deve ser ímpar. Tente novamente.")
        else:
            break
            
    except ValueError:
        print("Erro: Por favor, digite um número inteiro válido.")

print("\nPadrão gerado:")
imprimir_padrao(linhas)