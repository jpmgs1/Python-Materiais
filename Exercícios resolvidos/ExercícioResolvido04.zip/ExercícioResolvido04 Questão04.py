def obter_dados():
    """Solicita e retorna os dados do usuário"""
    print("\nPor favor, informe seus dados:")
    nome = input("Nome completo: ")
    nascimento = input("Data de nascimento (DD/MM/AAAA): ")
    celular = input("Celular para contato (com DDD): ")
    return nome, nascimento, celular

def mostrar_dados(nome, nascimento, celular):
    """Exibe os dados informados para confirmação"""
    print("\nConfirme seus dados:")
    print(f"Nome: {nome}")
    print(f"Data de Nascimento: {nascimento}")
    print(f"Celular: {celular}")

def validar_resposta():
    """Solicita e valida a resposta de confirmação"""
    while True:
        resposta = input("\nOs dados estão corretos? (sim/não): ").lower()
        if resposta in ['sim', 's', 'não', 'nao', 'n']:
            return resposta in ['sim', 's']
        print("Por favor, responda com 'sim' ou 'não'.")

def main():
    print("Bem-vindo ao sistema de cadastro!")
    
    while True:
        nome, nascimento, celular = obter_dados()
        
        mostrar_dados(nome, nascimento, celular)
        
        if validar_resposta():
            print("\nObrigado pelas informações! Cadastro concluído com sucesso.")
            break
        else:
            print("\nVamos recomeçar...")

if __name__ == "__main__":
    main()