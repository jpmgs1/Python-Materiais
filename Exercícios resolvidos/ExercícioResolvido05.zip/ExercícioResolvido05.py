## Atividade - João Paulo - 1v - redes

tamanho = int(input("Digite o tamanho da lista: "))
numeros = []
for i in range(tamanho):
    num = int(input(f"Digite o {i+1}º número: "))
    numeros.append(num)

print("\nAnálise da lista:")

print("\na) Lista em ordem inversa:", numeros[::-1])

pares = [num for num in numeros if num % 2 == 0]
print("\nb) Números pares:", pares)

print("c) Quantidade de números pares:", len(pares))

impares = [num for num in numeros if num % 2 != 0]
print("\nd) Números ímpares:", impares)

print("e) Quantidade de números ímpares:", len(impares))

print("\nf) Menor valor da lista:", min(numeros))

print("g) Maior valor da lista:", max(numeros))

frequencia = {}
for num in numeros:
    frequencia[num] = frequencia.get(num, 0) + 1

print("\nh) Frequência dos elementos:")
for num in sorted(frequencia):
    print(f"* {num} aparece {frequencia[num]} vez{'es' if frequencia[num] > 1 else ''}")