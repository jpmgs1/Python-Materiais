letra = input("Digite uma letra: ").lower()

if letra in ['a', 'e', 'i', 'o', 'u']:
  print("É uma vogal.")
else:
  print("Não é uma vogal.")