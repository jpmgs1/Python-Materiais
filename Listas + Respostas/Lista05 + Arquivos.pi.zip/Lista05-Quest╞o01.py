## Lista 05 - João Paulo - 1v - redes
def calcular_media(nota1, nota2, nota3, tipo):
    if tipo == 'A':
        media = (nota1 + nota2 + nota3) / 3
        return media
    elif tipo == 'P':
        media = (nota1 * 5 + nota2 * 3 + nota3 * 2) / (5 + 3 + 2)
        return media
    else:
        return -1

print("=== Cálculo de Média ===")

n1 = float(input("Digite a primeira nota: "))
n2 = float(input("Digite a segunda nota: "))
n3 = float(input("Digite a terceira nota: "))

letra = input("Digite o tipo de média (A para aritmética, P para ponderada): ").upper()

resultado = calcular_media(n1, n2, n3, letra)

if resultado == -1:
    print("Tipo de média inválido! Use A ou P.")
else:
    print(f"A média calculada foi: {resultado:.2f}")
