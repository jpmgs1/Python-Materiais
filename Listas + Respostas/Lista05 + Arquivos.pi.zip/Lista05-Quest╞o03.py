## Lista 05 - João Paulo - 1v - redes
def fibonacci(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

print("=== Sequência de Fibonacci (recursiva) ===")

N = int(input("Quantos termos da sequência você quer ver? "))

print("\nSequência de Fibonacci:")
for i in range(N):
    print(fibonacci(i), end=" ")

print()
