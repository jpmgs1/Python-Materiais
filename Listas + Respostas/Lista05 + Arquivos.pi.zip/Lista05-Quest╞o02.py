## Lista 05 - João Paulo - 1v - redes
def fatorial(n):
    if n == 0 or n == 1:
        return 1
    resultado = 1
    for i in range(2, n + 1):
        resultado *= i
    return resultado

def vetor_fatoriais(vetor):
    resultado = []
    for numero in vetor:
        f = fatorial(numero)
        resultado.append(f)
    return resultado

print("=== Cálculo de Fatoriais em Vetor ===")

tamanho = int(input("Quantos números você vai digitar? "))

vetor_original = []
for i in range(tamanho):
    valor = int(input(f"Digite o {i+1}º número inteiro: "))
    vetor_original.append(valor)

vetor_fatorado = vetor_fatoriais(vetor_original)

print("\nVetor original: ", vetor_original)
print("Vetor de fatoriais:", vetor_fatorado)
