## Lista 06 - João Paulo - 1v - redes
import csv

def carregar_alunos(nome_arquivo):
    alunos = {}
    try:
        with open(nome_arquivo, newline='', encoding='utf-8') as csvfile:
            leitor = csv.DictReader(csvfile, delimiter=';')
            for linha in leitor:
                matricula = linha.get('matricula', '').strip()

                alunos[matricula] = {
                    'nome': linha.get('nome', 'N/A').strip(),
                    'curso': linha.get('curso', 'N/A').strip(),
                    'campus': linha.get('campus', 'N/A').strip(),
                    'situacao': linha.get('situacao', 'N/A').strip(),
                    'matricula': matricula
                }

    except FileNotFoundError:
        print(f"Erro: Arquivo '{nome_arquivo}' não encontrado.")
    return alunos

def buscar_aluno_por_matricula(alunos, matricula):
    return alunos.get(matricula)

def main():
    arquivo_csv = 'alunos.csv'
    alunos = carregar_alunos(arquivo_csv)

    if not alunos:
        print("Não foi possível carregar os dados dos alunos.")
        return

    while True:
        entrada = input("Digite a matrícula do aluno (ou 0 para sair): ").strip()
        if entrada == '0':
            print("Programa encerrado.")
            break

        aluno = buscar_aluno_por_matricula(alunos, entrada)
        if aluno:
            print("\nAluno encontrado:")
            print(f"Nome     : {aluno['nome']}")
            print(f"Matrícula: {aluno['matricula']}")
            print(f"Curso    : {aluno['curso']}")
            print(f"Campus   : {aluno['campus']}")
            print(f"Situação : {aluno['situacao']}\n")
        else:
            print("Matrícula não encontrada.\n")

if __name__ == "__main__":
    main()

