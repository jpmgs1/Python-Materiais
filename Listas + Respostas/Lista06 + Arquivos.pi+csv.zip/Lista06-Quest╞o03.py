## Lista 06 - João Paulo - 1v - redes
def exibir_menu():
    print("\n=========== MENU ===========")
    print("1) Adicionar contato")
    print("2) Buscar contato por e-mail")
    print("3) Listar todos os contatos")
    print("4) Sair")
    print("============================")

def adicionar_contato(contatos):
    email = input("Digite o e-mail do contato: ").strip().lower()
    if email in contatos:
        print("Erro: já existe um contato com esse e-mail.")
        return
    nome = input("Digite o nome do contato: ").strip()
    telefone = input("Digite o telefone do contato: ").strip()
    contatos[email] = {'nome': nome, 'telefone': telefone}
    print("Contato adicionado com sucesso.")

def buscar_contato(contatos):
    email = input("Digite o e-mail do contato que deseja buscar: ").strip().lower()
    if email in contatos:
        contato = contatos[email]
        print(f"\n--- Contato encontrado ---")
        print(f"Nome    : {contato['nome']}")
        print(f"E-mail  : {email}")
        print(f"Telefone: {contato['telefone']}")
    else:
        print("Contato não encontrado.")

def listar_contatos(contatos):
    if not contatos:
        print("Nenhum contato na agenda.")
        return
    print("\n--- Lista de Contatos ---")
    for email, dados in contatos.items():
        print(f"Nome    : {dados['nome']}")
        print(f"E-mail  : {email}")
        print(f"Telefone: {dados['telefone']}")
        print("-" * 30)

def main():
    contatos = {}
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção (1-4): ").strip()
        
        if opcao == '1':
            adicionar_contato(contatos)
        elif opcao == '2':
            buscar_contato(contatos)
        elif opcao == '3':
            listar_contatos(contatos)
        elif opcao == '4':
            print("Encerrando o programa.")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
