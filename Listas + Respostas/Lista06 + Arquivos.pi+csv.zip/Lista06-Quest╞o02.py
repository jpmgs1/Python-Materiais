## Lista 06 - João Paulo - 1v - redes
import csv

def buscar_professores(nome_arquivo):
    while True:
        disciplina_input = input("Digite parte do nome da disciplina de ingresso (ou 'sair' para encerrar): ").strip().lower()
        if disciplina_input == "sair":
            print("Programa encerrado.")
            break

        campus_input = input("Digite parte do nome do campus (ex: ZL, MO, JC): ").strip().lower()
        encontrados = []

        try:
            with open(nome_arquivo, newline='', encoding='utf-8') as csvfile:
                leitor = csv.DictReader(csvfile, delimiter=';')
                for linha in leitor:
                    disciplina_csv = linha.get('disciplina_ingresso', '').strip().lower()
                    campus_csv = linha.get('campus', '').strip().lower()

                    if disciplina_input in disciplina_csv and campus_input in campus_csv:
                        encontrados.append({
                            'Nome': linha.get('nome', 'N/A').strip(),
                            'Matrícula': linha.get('matricula', 'N/A').strip(),
                            'Email': "Não informado"
                        })

        except FileNotFoundError:
            print(f"Erro: Arquivo '{nome_arquivo}' não encontrado.")
            return
        except KeyError as e:
            print(f"Erro: Coluna '{e}' não encontrada no CSV.")
            return

        if encontrados:
            print(f"\n{len(encontrados)} professor(es) encontrado(s):")
            for prof in encontrados:
                print(f"Nome     : {prof['Nome']}")
                print(f"Matrícula: {prof['Matrícula']}")
                print(f"E-mail   : {prof['Email']}\n")
        else:
            print("Nenhum professor encontrado com os critérios informados.\n")

# Executa o programa
buscar_professores('servidores.csv')
