## Lista 06 - João Paulo - 1v - redes
import csv
import os

ARQUIVO = "produtos.csv"
CAMPOS = ['codigo', 'nome', 'preco', 'quantidade', 'fornecedor']

def carregar_produtos():
    produtos = []
    if os.path.exists(ARQUIVO):
        with open(ARQUIVO, newline='', encoding='utf-8') as csvfile:
            leitor = csv.DictReader(csvfile)
            for linha in leitor:
                try:
                    linha['codigo'] = int(linha['codigo'])
                    linha['preco'] = float(linha['preco'])
                    linha['quantidade'] = int(linha['quantidade'])
                    produtos.append(linha)
                except ValueError:
                    print(f"Dados inválidos no arquivo: {linha}, ignorando esta linha.")
    return produtos

def salvar_produtos(produtos):
    with open(ARQUIVO, 'w', newline='', encoding='utf-8') as csvfile:
        escritor = csv.DictWriter(csvfile, fieldnames=CAMPOS)
        escritor.writeheader()
        for p in produtos:
            escritor.writerow(p)

def cadastrar_produto(produtos):
    try:
        codigo = int(input("Digite o código do produto (inteiro): "))
        if any(p['codigo'] == codigo for p in produtos):
            print("Código de produto já cadastrado!")
            return
        nome = input("Digite o nome do produto: ").strip()
        preco_str = input("Digite o preço do produto: ").strip()
        preco_str = preco_str.replace(',', '.')  # aceitar vírgula
        preco = float(preco_str)
        quantidade = int(input("Digite a quantidade em estoque: "))
        fornecedor = input("Digite o nome do fornecedor: ").strip()
        novo = {
            'codigo': codigo,
            'nome': nome,
            'preco': preco,
            'quantidade': quantidade,
            'fornecedor': fornecedor
        }
        produtos.append(novo)
        salvar_produtos(produtos)
        print("Produto cadastrado com sucesso!")
    except ValueError:
        print("Erro: Entrada inválida.")

def listar_produtos(produtos):
    if not produtos:
        print("Nenhum produto cadastrado.")
        return
    print("\n--- Lista de Produtos ---")
    for p in produtos:
        print(f"Código     : {p['codigo']}")
        print(f"Nome       : {p['nome']}")
        print(f"Preço      : R$ {p['preco']:.2f}")
        print(f"Quantidade : {p['quantidade']}")
        print(f"Fornecedor : {p['fornecedor']}")
        print("-" * 30)

def listar_por_faixa_preco(produtos):
    try:
        minimo_str = input("Digite o preço mínimo: ").strip()
        minimo_str = minimo_str.replace(',', '.')
        minimo = float(minimo_str)
        maximo_str = input("Digite o preço máximo: ").strip()
        maximo_str = maximo_str.replace(',', '.')
        maximo = float(maximo_str)
        filtrados = [p for p in produtos if minimo <= p['preco'] <= maximo]
        if not filtrados:
            print("Nenhum produto encontrado nessa faixa de preço.")
            return
        for p in filtrados:
            print(f"Código     : {p['codigo']}")
            print(f"Nome       : {p['nome']}")
            print(f"Preço      : R$ {p['preco']:.2f}")
            print(f"Quantidade : {p['quantidade']}")
            print(f"Fornecedor : {p['fornecedor']}")
            print("-" * 30)
    except ValueError:
        print("Erro: entrada inválida.")

def buscar_por_codigo(produtos):
    try:
        codigo = int(input("Digite o código do produto: "))
        for p in produtos:
            if p['codigo'] == codigo:
                print(f"\n--- Produto encontrado ---")
                print(f"Nome       : {p['nome']}")
                print(f"Preço      : R$ {p['preco']:.2f}")
                print(f"Quantidade : {p['quantidade']}")
                print(f"Fornecedor : {p['fornecedor']}")
                return
        print("Produto não encontrado.")
    except ValueError:
        print("Erro: código inválido.")

def menu():
    produtos = carregar_produtos()
    while True:
        print("\nEscolha sua opção:")
        print("0 – Sair do programa")
        print("1 – Cadastrar um novo produto")
        print("2 – Listar todos os produtos cadastrados")
        print("3 – Listar todos os produtos entre uma faixa de preços")
        print("4 – Mostrar um produto a partir de seu código")
        opcao = input(">> ").strip()

        if opcao == '0':
            print("Encerrando o programa.")
            break
        elif opcao == '1':
            cadastrar_produto(produtos)
        elif opcao == '2':
            listar_produtos(produtos)
        elif opcao == '3':
            listar_por_faixa_preco(produtos)
        elif opcao == '4':
            buscar_por_codigo(produtos)
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    menu()
