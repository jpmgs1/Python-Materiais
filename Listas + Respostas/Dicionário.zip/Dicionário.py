## Atividade Dicionário - João Paulo - 1v - redes
def main():
    dicionario = {}
    
    while True:
        print("\n--- Dicionário de Palavras ---")
        print("1. Adicionar palavra")
        print("2. Remover palavra")
        print("3. Consultar palavra")
        print("4. Listar todas as palavras com significados")
        print("5. Sair")
        
        opcao = input("Escolha uma opção (1-5): ").strip()
        
        if opcao == "1":
            palavra = input("Digite a palavra: ").strip().lower()
            significado = input("Digite o significado: ").strip()
            
            if palavra in dicionario:
                print(f"\nA palavra '{palavra}' já está cadastrada!")
                print(f"Significado atual: {dicionario[palavra]}")
                
                sugestoes = [p for p in dicionario.keys() if p.startswith(palavra[:3]) and p != palavra]
                if sugestoes:
                    print("\nPalavras similares já cadastradas:")
                    for sug in sugestoes[:3]:
                        print(f"- {sug}: {dicionario[sug]}")
                
                while True:
                    resposta = input("\nDeseja atualizar o significado? (S/N): ").strip().lower()
                    if resposta in ['s', 'n']:
                        break
                    print("Por favor, digite S ou N.")
                
                if resposta == 's':
                    dicionario[palavra] = significado
                    print(f"Significado de '{palavra}' atualizado com sucesso!")
                else:
                    print("Operação cancelada.")
            else:
                dicionario[palavra] = significado
                print(f"Palavra '{palavra}' adicionada com sucesso!")
                
        elif opcao == "2":
            palavra = input("Digite a palavra a ser removida: ").strip().lower()
            
            if palavra in dicionario:
                del dicionario[palavra]
                print(f"Palavra '{palavra}' removida com sucesso!")
            else:
                print(f"Palavra '{palavra}' não encontrada no dicionário.")
                
        elif opcao == "3":
            palavra = input("Digite a palavra a ser consultada: ").strip().lower()
            
            if palavra in dicionario:
                print(f"\nSignificado de '{palavra}':")
                print(f"{dicionario[palavra]}")
            else:
                print(f"Palavra '{palavra}' não encontrada no dicionário.")
                sugestoes = [p for p in dicionario.keys() if p.startswith(palavra[:3])]
                if sugestoes:
                    print("Talvez você quis dizer:")
                    for sug in sugestoes[:3]:
                        print(f"- {sug}")
                
        elif opcao == "4":
            if not dicionario:
                print("O dicionário está vazio.")
            else:
                print("\n--- Todas as palavras e significados ---")
                for i, (palavra, significado) in enumerate(sorted(dicionario.items()), 1):
                    print(f"\n{i}. {palavra.capitalize()}:")
                    print(f"   {significado}")
                print("\n--------------------------------------")
                
        elif opcao == "5":
            print("Saindo do programa...")
            break
            
        else:
            print("Opção inválida. Por favor, escolha uma opção de 1 a 5.")

if __name__ == "__main__":
    main()