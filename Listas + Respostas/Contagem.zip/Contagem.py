## Atividade Contagem de palavras - João Paulo - 1v - redes
import string
from collections import defaultdict

def main():
    texto = input("Digite o texto: ")
    tradutor = str.maketrans('', '', string.punctuation + '«»“”‘’')
    palavras = texto.lower().translate(tradutor).split()
    
    contador = defaultdict(int)
    for palavra in palavras:
        contador[palavra] += 1
    
    print("\nEstatísticas:")
    print(f"Total: {sum(contador.values())}")
    print(f"Únicas: {len(contador)}")
    
    print("\nFrequência:")
    for palavra, freq in sorted(contador.items()):
        print(f"{palavra}: {freq}")

if __name__ == "__main__":
    main()