#Lista 01 - Questão 22

h = int(input("Hora: "))
m = int(input("Minutos: "))

a = h * 60            
b = a + m             
c = b * 60            

print("a) Minutos:", a)
print("b) Total minutos:", b)
print("c) Segundos:", c)