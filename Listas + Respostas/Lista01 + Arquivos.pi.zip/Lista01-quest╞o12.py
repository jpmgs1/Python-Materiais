#Lista 01 - Questão 12

diagonalmaior = float(input("Digite o valor da diagonal maior: "))
diagonalmenor = float(input("Digite o valor da diagonal menor: "))
area = (diagonalmaior * diagonalmenor) / 2
print("A área do losango é:", area)