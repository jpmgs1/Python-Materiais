#Lista 01 - Questão 21

angulo1 = float(input("Digite o primeiro ângulo (em graus): "))
angulo2 = float(input("Digite o segundo ângulo (em graus): "))

terceiro_angulo = 180 - angulo1 - angulo2

print(f"O terceiro ângulo mede: {terceiro_angulo} graus")