#Lista 01 - Questão 04 (João-Paulo)

a = int(input("Digite o número (a): "))
b = int(input("Digite o número (b): "))

print("Normal:")
print("a =", a)
print("b =", b)

a, b = b, a

print("Inverso:")
print("a =", a)
print("b =", b)
