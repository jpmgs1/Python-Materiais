#Lista 01 - Questão 09

peso_kg = float(input("Digite o peso em quilos (kg): "))

peso_gramas = peso_kg * 1000

print("O peso em gramas é:", peso_gramas, "g")