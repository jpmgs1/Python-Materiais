#Lista 01 - Questão 03 (João-Paulo)

num1 = int(input("Digite o um número inteiro: "))
num2 = int(input("Digite outro número inteiro: "))
divisaointeira = num1 // num2
resto = num1 % num2
divisaoreal = num1 / num2

print("\nResultados:")
print("Divisão inteira:", divisaointeira)
print("Resto da divisão:", resto)
print("Divisão real:", divisaoreal)
