#Lista 01 - Questão 08

#a)
peso = float(input("Digite o peso atual (kg): "))
aumento = peso * 0.15
novo_peso = peso + aumento

print(f"Peso original: {peso:.2f} kg")
print(f"Aumento de 15%: {aumento:.2f} kg")
print(f"Novo peso: {novo_peso:.2f} kg")

#b)
peso = float(input("Digite o peso atual (kg): "))

aumento = peso * 0.20
novo_peso = peso + aumento

print(f"Peso original: {peso:.2f} kg")
print(f"Aumento de 20%: {aumento:.2f} kg")
print(f"Novo peso: {novo_peso:.2f} kg")