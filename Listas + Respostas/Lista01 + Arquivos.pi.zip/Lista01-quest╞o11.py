#Lista 01 - Questão 11

lado = float(input("Digite o valor do lado do quadrado: "))
area = lado * lado
print("A área do quadrado é:", area)