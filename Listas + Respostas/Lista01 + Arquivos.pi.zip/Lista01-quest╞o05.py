#Lista 01 - Questão 05

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))

mediaponderada = (nota1 * 2 + nota2 * 3) / 5

print("A média ponderada é:", mediaponderada)

