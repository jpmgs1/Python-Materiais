#Lista 01 - Questão 02 (João-Paulo)

a = float(input("Digite o valor de a: "))
b = float(input("Digite o valor de b: "))
c = float(input("Digite o valor de c: "))

subtracao = a - b - c
soma = a + b + c
multiplicacao = a * b * c
divisao = a / b / c

print("\nResultados:")
print("Subtração (a - b - c):", subtracao)
print("Soma (a + b + c):", soma)
print("Multiplicação (a * b * c):", multiplicacao)
print("Divisão (a / b / c):", divisao)
