#Lista 01 - Questão 18

celsius = float(input("Digite a temperatura em Celsius: "))

fahrenheit = (9/5) * celsius + 32

print(f"\n{celsius:.1f}°C equivalem a {fahrenheit:.1f}°F")