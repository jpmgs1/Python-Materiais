#Lista 01 - Questão 01 (João-Paulo)

#a)
resultado = (10 + (20 * 30))
print(resultado)
#b)
resultado = (4**2) / 30
print(resultado)
#c)
resultado = (9**4 + 2) * (6-1)
print(resultado)
#d)
resultado = (10 % 3 * 10 ** 2) + (1 - 10) * (4 / 2)
print(resultado)